# Logótipo Phlox 3D

Logótipo tridimensional do Phlox Clinical: a palavra **phlox** em Lora itálico,
extrudida com bisel a partir do ficheiro TTF, com o **“o” substituído por uma flor
de *Phlox paniculata*** gerada por superfícies paramétricas (pétalas com espessura
real, veios, torção, cores por vértice, estames e folhas).

Anima assim: **floresce uma vez** quando entra em ecrã (~1,9 s) e depois **roda
continuamente sobre o eixo vertical**. A rotação é uma ilusão — existem duas cópias
montadas dorso-a-dorso e a troca acontece no instante em que as letras ficam de
perfil, por isso a palavra lê-se **sempre “phlox”, nunca espelhada**.

---

## O que está aqui

    src/phlox-logo-element.js   <phlox-logo> — o elemento pronto a usar
    src/phlox-logotype.js       gerador do logótipo (palavra + flor)
    src/phlox-mark.js           geometria paramétrica da flor, folhas e pétalas
    src/fonts/                  Lora Italic + Cormorant Garamond Italic (OFL)
    demo/index.html             demonstração em 4 variantes
    exportar.html               abre no browser e descarrega GLB, glTF, OBJ+MTL,
                                STL, PLY, USDZ e PNG 4× transparente

Os ficheiros de malha **não vêm no pacote de propósito**: a geometria é gerada por
código (mais leve, e escala sem perder definição). Abre `exportar.html` e clica
**“Descarregar tudo”** se precisares dos ficheiros estáticos.

## Instalar no site

    npm install three

```html
<phlox-logo color="#16181d"></phlox-logo>
<script type="module" src="/phlox-logo/src/phlox-logo-element.js"></script>
```

Em Next.js / React:

```jsx
'use client';
import { useEffect } from 'react';

export function PhloxLogo3D(props) {
  useEffect(() => { import('@/lib/phlox-logo/phlox-logo-element.js'); }, []);
  return <phlox-logo {...props} />;
}
```

No rodapé do Phlox (fundo branco) usa `color="#16181d"`; num rodapé escuro usa
`color="#f7f8f5" env="dark"`.

### Atributos

| Atributo | Predefinição | Notas |
|---|---|---|
| `color` | `#16181d` | cor das letras — `--ink` ou `--green` (#0d6e42) |
| `font` | `lora` | `lora` (serifa da marca) ou `cormorant` (mais dramática) |
| `speed` | `0.42` | rad/s da rotação |
| `punch` | `0.24` | 0–1, quanto rosa entra nas pétalas |
| `flower-scale` | `0.94` | tamanho do “o” face às letras |
| `env` | `light` | `dark` para fundos escuros (ajusta reflexos) |
| `static` | — | sem rotação nem florescer, na pose final |

Tamanho pelo CSS (o elemento é `display:block`, 260×108 px por omissão):

```css
phlox-logo { width: 260px; }        /* mantém a proporção 260/108 */
```

Dispara um evento `ready` quando a malha está montada.

### Comportamento já tratado

- Fundo **transparente** — herda o que estiver por baixo.
- Pára de desenhar quando sai do ecrã (`IntersectionObserver`).
- Respeita `prefers-reduced-motion`: mostra a pose final, sem movimento.
- Arrastável com rato/dedo (soma-se à rotação).
- `devicePixelRatio` limitado a 2 e `ResizeObserver` para o reenquadramento.

## Formatos de exportação

| Formato | Para que serve |
|---|---|
| **GLB** | O melhor para web e Blender — hierarquia, materiais PBR, cores por vértice |
| glTF | O mesmo em JSON, para inspecionar/editar à mão |
| OBJ + MTL | Compatibilidade universal (Fusion, C4D, ZBrush). Sem cores por vértice |
| STL | Impressão 3D e CAD. Só geometria |
| PLY | Geometria com cores por vértice |
| USDZ | Realidade aumentada no iOS (Quick Look) |
| PNG 4× | Render transparente para favicon, e-mail, sítios sem 3D |

O ficheiro estático é uma **pose fixa** (flor aberta). A animação existe apenas na
versão por código — se precisares dela, usa `<phlox-logo>`, não o GLB.

## Notas técnicas

- Requer **three.js ≥ 0.160** (`three`, `three/addons/loaders/{FontLoader,TTFLoader}`,
  `three/addons/geometries/TextGeometry`). A demo carrega-o do unpkg via importmap;
  num projeto com bundler os *bare specifiers* resolvem-se sozinhos.
- Nada de primitivas: pétalas, folhas, sépalas e botões são superfícies
  paramétricas amostradas com normais analíticas e casca de espessura real; caule
  e pedicelos são varrimentos ao longo de curvas Catmull-Rom.
- As cores das pétalas viajam como *vertex colors* — sobrevivem em GLB e PLY;
  em OBJ só ficam as cores por material.
- A rotação-ilusão duplica a geometria (~2×). Para um rodapé é irrelevante; se
  precisares de uma só cópia, usa `buildPhloxLogotype()` em vez de
  `buildSpinningLogotype()`.

## Licenças

Geometria e código: teus, do projeto Phlox. Fontes **Lora** e **Cormorant Garamond**:
SIL Open Font License 1.1 (Google Fonts) — redistribuíveis, incluídas em `src/fonts/`.
